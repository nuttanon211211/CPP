#include <iostream>

using namespace std;

int main()
{
    int n,m,i,x,y,v[500][500];
    cin >>n>>m;
    for(x=0;x<n;x++){
        for(y=0;y<m;y++) {
            cin >>i;
            if(x&&y) v[x][y] = max((i<<1) +v[x-1][y-1],i+max(v[x][y-1],v[x-1][y]));
            else if (x) v[x][y] = i + v[x-1][y];
            else if (y) v[x][y] = i + v[x][y-1];
            else v[x][y] = i;
        }
    }
    cout << v[--n][--m] << endl;
    return 0;
}
