#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n,k;
    vector<int> number;
    cin >> n >> k;
    int mem[n+1][k+1];
    int v[n+1] , w[n+1];
    for(int i = 1;i  <=n;i++){
        cin >> v[i];
    }
    for(int i=1;i <=n;i++){
        cin >> w[i];
    }
    for(int i=0;i<= n;i++){
        for(int j = 0;j<=k;j++) {
            if(i==0 || j==0) mem[i][j] = 0;
        }
    }
    for(int i=1;i<=n;i++) {
        for(int j = 1;j <=k;j++){
            if( j >= w[i]) {
                if (mem[i-1][j] > mem[i-1][j-w[i]] + v[i] ){
                    mem[i][j] = mem[i-1][j];
                } else {
                    mem[i][j] = mem[i-1][j-w[i]]+v[i];
                }
            }   else mem[i][j] = mem[i-1][j];
        }
    }

    int i = n,j = k;
    while (i>0 && j>0) {
        if(mem[i-1][j] == mem[i][j]) i--;
        else {
            number.push_back(i);
            j -= w[i];
            i--;

        }
    }
    cout << number.size() << endl;
    for(int i = number.size()-1;i>=0;i--){
        cout << number[i] << " ";
    }
    return 0;
}
