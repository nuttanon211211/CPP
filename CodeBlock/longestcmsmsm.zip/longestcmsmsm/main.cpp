#include <iostream>
#include <vector>

using namespace std;


/*int max_suffix(int r){
    if (a.size() == 1){
        return a[0];
    }
    return max(a[r],max_suffix(r-1)+a[r]);
}
*/
int main()
{
    int n,temp,sum,mx;
    scanf("%d",&n);
    scanf("%d",&temp);
    sum = temp;
    mx = temp;

    for(int i =1;i<n;i++){

        mx = max(mx ,sum);
        if(sum < 0 ) sum = 0;
        scanf("%d",&temp);
        sum += temp;
    }

    cout << max(mx , sum);
    return 0;
}
