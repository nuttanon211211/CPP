#include <iostream>
#include <deque>

using namespace std;

int main()
{
    deque<pair<int,int>> dq;
    int n,w;
    cin >> n >> w;
    int ans = 0;
    for (int i = 0, s = 0;i<n;i++) {
        int val;
        cin >> val;
        s += val;

        while (!dq.empty() && dq.front().first < i-w) dq.pop_front();

        if (i==0) {
            ans = val;
        } else {
            ans = max(ans, s- dq.front().second);
        }

        while (!dq.empty() && dq.back().second >= s) dq.pop_back();
        dq.push_back({i,s});
    }
    cout << ans << endl;
    return 0;
}
