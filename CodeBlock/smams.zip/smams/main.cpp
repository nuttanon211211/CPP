#include <iostream>
#include <string>

using namespace std;
string a,b;
bool same(int aa,int bb,int l) {
    if(l==1) return a[aa] == b[bb];
    return same(aa,bb,l/2)&&same(aa+l/2,bb+l/2,l/2) || same(aa,bb+l/2,l/2)&&same(aa+l/2,bb,l/2);

}
/*bool sameSame(string a,string b){
    if(a==b){
        return true;
    }
    string a1,a2,b1,b2;
    a1 = a.substr(0 , a.length()/2);
    a2 = a.substr( a.length()/2 );
    b1 = b.substr(0 , b.length()/2);
    b2 = b.substr( b.length()/2 );
    return ( (sameSame(a1,b1)&&sameSame(a2,b2)) || (sameSame(a1,b2)&&sameSame(a2,b1)));
}

void test(){
    string t = "ab";
    string t1,t2;
    t1 = t.substr(0,t.length()/2);
    t2 = t.substr(t.length()/2);
    cout << t1 << "\n" << t2;
}*/

int main()
{
    //string a,b;
    cin >> a;
    cin >> b;
    if(same(0,0,a.length())){
        cout << "YES";
    }else {
        cout << "NO";
    }
    //test();
    //cout << "Hello world!" << endl;
    return 0;
}
