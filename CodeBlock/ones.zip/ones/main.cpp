#include <iostream>

using namespace std;
int q[]= {0,1,11,111,1111,11111,111111,1111111,11111111};
int calc(int x){
    switch(abs(x)){
        case 0: return 0;
        case 1: return 1;
        case 2: return  2;
        case 3: return  3;
        case 4: return  4;
        case 5: return  5;
        case 6: return  6;
        case 7: return  6;
        case 8: return  5;
        case 9: return  4;
        case 10: return  3;
        case 11: return  2;
        default:
        {
            int i;
            for(i=1;q[i]<= abs(x);i++);
            int x1 = q[i-1],c1 = i-1;
            while (x1 < x)
            {
                x1 += q[i-1];
                c1 += i-1;
            }
            if (c1 != i-1)
            {
                x1 -= q[i-1];
                c1 -= i-1;
            }
            c1 += calc(abs(x-x1));

            int x2 = q[i], c2 = i;
            while (x2 > x)
            {
                x2 -= q[i-1];
                c2 += i-1;
            }
            x2 += q[i-1];
                c2 -=i-1;
                c2 += calc(abs(x-x2));
                return min(c1,c2);

        }

    }

}

int main()
{
    int x;
    cin >> x;
    cout << calc(x)<< endl;

    return 0;
}
