#include <iostream>

using namespace std;

int main()
{
    int n.m,k;
    cin >> n >> m>> k;
    int p[n][m];

    cout << "Hello world!" << endl;
    return 0;
}
